package universidad.tipos;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Persona {
	private String DNI;
	private String nombre;
	private String apellidos;
	private LocalDate fecha_n;
	private String gmail;
	
	
	//Constructores
	public Persona(String Dni,String nombre,String apellido, LocalDate fecha_n, String gmail) {
		this.DNI = Dni;
		this.apellidos = apellido;
		this.nombre = nombre;
		this.fecha_n = fecha_n;
		this.gmail = gmail;
		
}
	public Persona(String Dni,String nombre,String apellido, LocalDate fecha_n) {
		this.DNI = Dni;
		this.apellidos = apellido;
		this.nombre = nombre;
		this.fecha_n = fecha_n;
		this.gmail = "";
	}
	//Getters
	private String get_Dni() {
		return DNI;}
	private String get_Apellidos() {
		return apellidos;	}
	private String get_Nombre() {
			return nombre;}
	private String get_gmail() {
			return gmail;}
	private LocalDate get_fecha_n() {
		return fecha_n;}
	private Integer get_edad() {
		Integer edad = get_fecha_n().until(LocalDate.now()).getYears();
		return edad;}
	//Setters
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String toString() {
		return get_Dni() +" - " + get_Apellidos()+ " ," + get_Nombre( )+ " - " + get_fecha_n().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}

	}

