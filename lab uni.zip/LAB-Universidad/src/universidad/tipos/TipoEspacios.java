package universidad.tipos;

public enum TipoEspacios {aulateoría, laboratorio, seminario, aulaexamen

}
