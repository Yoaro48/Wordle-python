package universidad.tipos;

import java.time.LocalDate;

public class Espacio {
	String nombre;
	Integer capacidad;
	Integer planta;
	TipoEspacios tipo;
	//constructores
	public Espacio(String nombre,Integer capacidad,Integer planta,TipoEspacios tipo) {
		this.nombre = nombre;
		this.tipo = tipo;
		this.capacidad = capacidad;
		this.planta = planta;
	}
	//Getters
	private Integer capacidad() {
		return capacidad;}
	
	private String get_Nombre() {
			return nombre;}
	private Integer get_planta() {
			return planta;}
	private TipoEspacios get_tipo() {
		return tipo;}
	
	//Setters 
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return nombre + " (planta" + planta + ")";
	}
	
}
