package universidad.tipos.test;
import java.time.LocalDate;
import universidad.tipos.Persona;

public class TestPersona {
	public static void main(String[] args) {
		Persona Persona1 = new Persona("12345678W","Jose Luis", "Garcia", LocalDate.of(2006, 11, 4));
		System.out.println(Persona1);
	}
}
